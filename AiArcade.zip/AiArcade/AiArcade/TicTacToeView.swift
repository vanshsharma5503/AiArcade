import SwiftUI

struct TicTacToeView: View {
    @Binding var isPresented: Bool
    @State private var board: [String] = Array(repeating: "", count: 9)
    @State private var currentPlayer = "X"
    @State private var gameEnded = false
    @State private var winner = ""
    
    var body: some View {
        VStack {
            HStack {
                Button("Back") {
                    isPresented = false
                }
                .font(.system(size:20))
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding()
                Spacer()
            }
            
            Text("Tic Tac Toe")
                .font(.system(size: 50))
                .fontWeight(.bold)
                .padding()
                .foregroundColor(.blue)
            
            LazyVGrid(columns: Array(repeating: GridItem(), count: 3), spacing: 5) { // Decreased horizontal gap to 5
                ForEach(0..<9) { index in
                    Button(action: {
                        if board[index] == "" && !gameEnded {
                            board[index] = currentPlayer
                            checkForWinner()
                            currentPlayer = currentPlayer == "X" ? "O" : "X"
                            if !gameEnded {
                                performAIMove()
                            }
                        }
                    }) {
                        Text(board[index])
                            .font(.largeTitle)
                            .frame(width: 130, height: 130)
                            .foregroundColor(.white)
                            .background(Color.blue.opacity(0.5))
                            .cornerRadius(10)
                            .animation(.default)
                    }
                    .disabled(gameEnded || board[index] != "")
                }
            }
            .padding()
            
            if gameEnded {
                Text("Winner: \(winner)")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()
                    .foregroundColor(winner == "X" ? .green : winner == "O" ? .red : .blue)
                    .animation(.default)
            }
            
            Button(action: {
                resetGame()
            }) {
                Text("Reset Game")
                    .frame(width: 200)
                    .font(.headline)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .font(.system(size: 30))
            }
        }
        .navigationTitle("Tic Tac Toe")
        .onAppear {
            resetGame()
        }
    }
    
    private func checkForWinner() {
        let winPatterns: [[Int]] = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]]
        for pattern in winPatterns {
            if board[pattern[0]] != "" && board[pattern[0]] == board[pattern[1]] && board[pattern[1]] == board[pattern[2]] {
                winner = board[pattern[0]]
                gameEnded = true
                return
            }
        }
        if !board.contains("") {
            winner = "Draw!"
            gameEnded = true
        }
    }
    
    private func performAIMove() {
        // Simple AI: Randomly chooses an empty cell
        let emptyCells = board.indices.filter { board[$0] == "" }
        if let randomIndex = emptyCells.randomElement() {
            board[randomIndex] = currentPlayer
            checkForWinner()
            currentPlayer = currentPlayer == "X" ? "O" : "X"
        }
    }
    
    private func resetGame() {
        board = Array(repeating: "", count: 9)
        currentPlayer = "X"
        gameEnded = false
        winner = ""
    }
}

struct TicTacToeView_Previews: PreviewProvider {
    static var previews: some View {
        TicTacToeView(isPresented: .constant(true))
    }
}

