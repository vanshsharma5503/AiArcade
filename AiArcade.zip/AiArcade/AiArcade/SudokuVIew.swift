import SwiftUI

struct SudokuView: View {
    @Binding var isPresented: Bool
    @StateObject var board = BoardClass()
    @State var isSolved: Bool = false
    @State var selectedVal: Int = 0
    @State var undoStack: [(from: Int, index: Int, value: Int)] = []
    @State var redoStack: [(from: Int, index:Int, value:Int)] = []
    
    func getButtonColor(currentVal: Int, selectedVal: Int) -> Color {
        if (currentVal == selectedVal) {
            return Color.blue.opacity(0.8)
        } else {
            return Color.blue.opacity(0.5)
        }
    }
    
    func setSelectedVal(selected: Int) -> Void {
        selectedVal = selected
    }
    
    var body: some View {
        VStack(spacing:0) {
            HStack {
                Button("Back") {
                    isPresented = false
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding()
                Spacer()
            }
            Text("Sudoku")
                .bold()
                .padding([.bottom], 20)
                .font(.title3)
            ForEach(0 ..< board.items.count / 9, content: { row in
                HStack(spacing:0) {
                    ForEach(0 ..< 9, content: {
                        col in
                        let index = row * 9 + col
                        SquareView(data: board.items[index], onclick: {
                            if (self.board.items[index].squareVal == selectedVal) {return}
                            self.undoStack.append((self.board.items[index].squareVal, index, selectedVal))
                            self.board.setSquare(index: index, newVal: selectedVal)
                        })
                    })
                }
            })
            VStack(spacing:2) {
                HStack(spacing:2) {
                    ForEach(-2 ..< 4, content: { val in
                        Button(action: {
                            if (val >= 0) {
                                self.setSelectedVal(selected: val)
                                self.redoStack.removeAll()
                            } else if (val == -2) {
                                // undo action. So take it off top of undo stack, add it to redo stack
                                if (undoStack.count == 0) {return}
                                let lastAction = self.undoStack.removeLast()
                                self.redoStack.append(lastAction)
                                self.board.setSquare(index: lastAction.1, newVal: lastAction.0)
                            } else if (val == -1) {
                                // redo action. So take it off of redo stack and add it to undo stack
                                if (redoStack.count == 0) {return}
                                let lastAction = self.redoStack.removeLast()
                                self.undoStack.append(lastAction)
                                self.board.setSquare(index: lastAction.1, newVal: lastAction.2)
                            }
                        }, label: {
                            if (val == 0) {
                                Image("eraser")
                                    .foregroundColor(Color.white)
                                    .frame(width:40, height:40, alignment: .center)
                                    .border(Color.gray)
                                    .background(getButtonColor(currentVal: val, selectedVal: selectedVal))
                            } else if (val == -1) {
                                Image(systemName:"arrow.uturn.forward")
                                    .foregroundColor(Color.white)
                                    .frame(width:40, height:40, alignment: .center)
                                    .border(Color.gray)
                                    .background(getButtonColor(currentVal: val, selectedVal: selectedVal))
                            } else if (val == -2) {
                                Image(systemName:"arrow.uturn.backward")
                                    .foregroundColor(Color.white)
                                    .frame(width:40, height:40, alignment: .center)
                                    .border(Color.gray)
                                    .background(getButtonColor(currentVal: val, selectedVal: selectedVal))
                            } else {
                                Text(String(val))
                                    .bold()
                                    .foregroundColor(Color.white)
                                    .frame(width:40, height:40, alignment: .center)
                                    .border(Color.gray)
                                    .background(getButtonColor(currentVal: val, selectedVal: selectedVal))
                            }
                        })
                    })
                }
                HStack(spacing:2) {
                    ForEach(4 ..< 10, content: { val in
                        Button(action: {
                            self.setSelectedVal(selected: val)
                        }, label: {
                            Text(String(val))
                                .foregroundColor(Color.white)
                                .bold()
                                .frame(width:40, height:40, alignment: .center)
                                .border(Color.gray)
                                .background(getButtonColor(currentVal: val, selectedVal: selectedVal))
                        })
                    })
                }

            }
            .padding([.top, .bottom], 20)
            Button(action: {
                self.board.revealOne()
            }, label: {
                Text("Reveal One")
                    .foregroundColor(Color.white)
                    .bold()
                    .frame(alignment: .center)
                    .padding(10)
                    .border(Color.gray)
                    .background(Color.gray)
            })
                .padding(.bottom, 2)
            HStack(spacing:2) {
                Button(action: {
                    self.board.makeNewBoard()
                }, label: {
                    Text("New Game")
                        .foregroundColor(Color.white)
                        .bold()
                        .frame(alignment: .center)
                        .padding(10)
                        .border(Color.gray)
                        .background(Color.gray)
                })
                Button(action: {
                    self.board.solveBoard()
                    self.board.numSteps = 0
                }, label: {
                    Text("View Solution")
                        .foregroundColor(Color.white)
                        .bold()
                        .frame(alignment: .center)
                        .padding(10)
                        .border(Color.gray)
                        .background(Color.gray)
                })
            }
        }
    }
}

struct SudokuView_Previews: PreviewProvider {
    static var previews: some View {
        SudokuView(isPresented: .constant(true))
    }
}

import Foundation
import SwiftUI

class Square: ObservableObject {
    @Published var squareVal: Int
    @Published var index: Int
    @Published var row: Int
    @Published var col: Int
    @Published var isPermanent: Bool
    @Published var isHint: Bool
    @Published var isWrong: Bool
    
    init(value: Int, index: Int, rowCol:[Int], isPermanent:Bool) {
        self.squareVal = value
        self.index = index
        self.row = rowCol[0]
        self.col = rowCol[1]
        self.isPermanent = isPermanent
        self.isHint = false
        self.isWrong = false
    }
}

struct SquareView: View {
    @ObservedObject var data: Square
    
    var onclick: () -> Void
    
    var squareColor: Color {
        
        if (((self.data.col > 5 || self.data.col < 3) && (self.data.row > 5 || self.data.row < 3)) ||
            ((self.data.col <= 5 && self.data.col >= 3) && (self.data.row <= 5 && self.data.row >= 3))) {
            return .blue.opacity(0.5)
        } else {
            return .blue.opacity(0.8)
        }
    }
    
    var squareWeight: Font.Weight {
        if (self.data.isHint) {
            return .bold
        }
        if (self.data.isWrong) {
            return .bold
        }
        
        return self.data.isPermanent ? .bold : .light
    }
    
    var squareTextColor: Color {
        if (self.data.isHint) {
            return .white
        } else if (self.data.isWrong) {
            return .red.opacity(0.5)
        } else {
            return .black
        }
    }
    
    var body: some View {
        Button(action: {
            self.onclick()
        }, label: {
            Text(self.data.squareVal != 0 ? String(self.data.squareVal) : " ")
                .foregroundColor(squareTextColor)
                .fontWeight(squareWeight)
                .frame(width:40, height:40, alignment: .center)
                .border(Color.black.opacity(0.7))
                .background(squareColor)
        })
    }
}
import Foundation
import SwiftUI

class BoardClass: ObservableObject {
    @Published var items = [Square]()
    @Published var numSteps = 0
    @Published var currentPuzzle: [String] = [""]
    
    @Published var data: [[String]] = [
        ["831000000270006000000009001050001600700902050063000009006017005000000000000008093",
        "831574962279136548645829731952341687718962354463785219396417825584293176127658493"],
        ["560801000010000008000500070159600002600900031000000000090108050000070006070000800",
        "567841923314792568928563174159637482642985731783214695496128357835479216271356849"],
        ["570006000008504000006000030000000000100000800030080200080001060605300020010005073",
        "571936482328574619946128735859712346162453897437689251783291564695347128214865973"],
        ["410006000709800020000300000000090002600008100200007940120000000908600000064000208",
        "412976385739854621856321479547193862693248157281567943125489736978632514364715298"],
        ["300060090004200006000000200003900000400000508080020900670000035208000000009308007",
        "325861794814279356967543281753984162492136578186725943671492835238657419549318627"],
        ["000600340000004001000010906700001008000500090900800130040007800090405013007100059",
        "271689345639754281584213976763941528418532697952876134145397862896425713327168459"],
        ["000024000000030050005000100500000600802350901900806300410000030000000200029000418",
        "186524793794631852235978164543192687862357941971846325417289536658413279329765418"],
        ["001009050003005109070000034300000080200408500085391070000503200000000010000000000",
        "421839756863745129579126834394257681217468593685391472948513267732684915156972348"]
    ]
    
    init() {
        self.makeNewBoard()
    }
    
    func chooseNextPuzzle() {
        let prevPuzzle: [String] = currentPuzzle
        while (prevPuzzle == self.currentPuzzle) {
            self.currentPuzzle = self.data[Int.random(in:0..<(data.count))]
        }
    }
    
    func indexToRowCol(index: Int) -> [Int] {
        let row: Int = index / 9
        let col: Int = index % 9
        return [row, col]
    }
    
    func rowColToIndex(row:Int, col:Int) -> Int {
        return col + row * 9
    }
    
    func setSquare(index: Int, newVal: Int) -> Void {
        if (items[index].isPermanent) {
            return
        } else {
            items[index].squareVal = newVal
        }
    }
    
    func makeNewBoard() {
        self.chooseNextPuzzle()
        items.removeAll()
        for (i, ch) in currentPuzzle[0].map(String.init).enumerated() {
            items.append(Square(value:(Int(ch) ?? 0), index:i, rowCol:indexToRowCol(index: i),
                                isPermanent:(Int(ch) ?? 0) > 0))
        }
    }
    
    func isValid(rowIndex:Int, colIndex:Int, k:Int) -> Bool {
        for i in 0 ..< 9 {
          let m = 3 * (rowIndex / 3) + (i / 3);
          let n = 3 * (colIndex / 3) + (i % 3);
            if (items[rowColToIndex(row:rowIndex, col:i)].squareVal == k ||
                items[rowColToIndex(row:i, col:colIndex)].squareVal == k ||
                items[rowColToIndex(row:m, col:n)].squareVal == k) {
            return false;
          }
      }
      return true;
    }
    
    func revealOne() -> Void {
        for (i, ch) in currentPuzzle[1].map(String.init).enumerated() {
            if (self.items[i].squareVal == 0) {
                self.items[i].squareVal = Int(ch) ?? 0
                self.items[i].isHint = true
                break
            }
        }
    }

    
    func solveBoard() {
        for (i, ch) in currentPuzzle[1].map(String.init).enumerated() {
            if (self.items[i].squareVal > 0 && self.items[i].squareVal != Int(ch)) {
                self.items[i].isWrong = true
            } else {
                self.items[i].isWrong = false
                self.items[i].squareVal = Int(ch) ?? 0
            }
            
        }
    }
}
