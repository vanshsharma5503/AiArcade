import SwiftUI
struct PuzzleView: View {
    @Binding var isPresented: Bool
    let gridSize = 4
    let tileCount = 15

    @State private var tiles: [Int] = Array(1...15) + [0] // 0 represents the empty space
    @State private var shuffled = false

    var body: some View {
        VStack {
            HStack {
                Button("Back") {
                    isPresented = false
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding()
                Spacer()
            }

            Text("15 Puzzle Problem")
                .font(.largeTitle)
                .padding()

            LazyVGrid(columns: Array(repeating: GridItem(), count: gridSize)) {
                ForEach(tiles, id: \.self) { number in
                    Text(number != 0 ? "\(number)" : "")
                        .frame(width: 120, height: 120)
                        .background(Color.blue.opacity(0.5))
                        .cornerRadius(10)
                        .foregroundColor(.white)
                        .font(.title)
                        .onTapGesture {
                            moveTile(number)
                        }
                }
            }
            .padding()

            HStack {
                Button("Shuffle") {
                    shuffleTiles()
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding()

                Button("Solve") {
                    solvePuzzle()
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding()
                .disabled(!shuffled)
            }
        }
    }

    func moveTile(_ number: Int) {
        guard number != 0, let index = tiles.firstIndex(of: number) else { return }

        let emptyIndex = tiles.firstIndex(of: 0)!
        let emptyRow = emptyIndex / gridSize
        let emptyColumn = emptyIndex % gridSize
        let row = index / gridSize
        let column = index % gridSize

        if (row == emptyRow && abs(column - emptyColumn) == 1) || (column == emptyColumn && abs(row - emptyRow) == 1) {
            tiles.swapAt(index, emptyIndex)
        }
    }

    func shuffleTiles() {
        tiles.shuffle()
        shuffled = true
    }

    func solvePuzzle() {
        // Implement the logic to solve the puzzle
        tiles = Array(1...15) + [0] // Reset the tiles to their solved state
        shuffled = false
    }
}
struct PuzzleView_Previews: PreviewProvider {
    static var previews: some View {
        PuzzleView(isPresented: .constant(true))
    }
}
