//
//  AiArcadeApp.swift
//  AiArcade
//
//  Created by SHHH!! private on 07/03/24.
//

import SwiftUI


@main
struct TicTacToeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
