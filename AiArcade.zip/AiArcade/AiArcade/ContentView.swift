import SwiftUI

struct ContentView: View {
    @Environment(\.colorScheme) var colorScheme
    @State private var isTicTacToePresented = false
    @State private var isPuzzleViewPresented = false
    @State private var isSudokuViewPresented = false
    
    var body: some View {
        ZStack {
            VStack(spacing: 70) {
                Text("My Games")
                    .font(.system(size: 60, weight: .bold))
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                HStack(spacing: 50) {
                    Button(action: {
                        isSudokuViewPresented =  true
                    }) {
                        VStack {
                            Image("Soduko")
                                .resizable()
                                .frame(width: 300, height: 300)
                                .cornerRadius(20)
                                .shadow(radius: 20)
                            
                            Text("Sudoku")
                                .font(.title)
                                .foregroundColor(colorScheme == .dark ? .white : .black)
                        }
                    }
                    
                    Button(action: {
                        isPuzzleViewPresented = true
                    }) {
                        VStack {
                            Image("15puz")
                                .resizable()
                                .frame(width: 300, height: 300)
                                .cornerRadius(20)
                                .shadow(radius: 20)
                            
                            Text("15 Puzzle Problem")
                                .font(.title)
                                .foregroundColor(colorScheme == .dark ? .white : .black)
                        }
                    }
                    
                    Button(action: {
                        self.isTicTacToePresented.toggle()
                    }) {
                        VStack {
                            Image("ttt")
                                .resizable()
                                .frame(width: 300, height: 300)
                                .cornerRadius(20)
                                .shadow(radius: 20)
                            
                            Text("Tic Tac Toe")
                                .font(.title)
                                .foregroundColor(colorScheme == .dark ? .white : .black)
                        }
                    }
                }
                .padding()
                .frame(maxWidth: .infinity) // Ensure full width for landscape mode
            }
            .opacity(isTicTacToePresented || isPuzzleViewPresented || isSudokuViewPresented ? 0 : 1) // Hide main content when Tic Tac Toe or Puzzle or Sudoku View is presented
            
            if isTicTacToePresented {
                TicTacToeView(isPresented: $isTicTacToePresented)
            }
            
            if isPuzzleViewPresented {
                PuzzleView(isPresented: $isPuzzleViewPresented)
            }
            
            if isSudokuViewPresented {
                SudokuView(isPresented: $isSudokuViewPresented)
            }
        }
        .navigationTitle("My Games")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .previewDevice("iPad (9th generation)")
            .preferredColorScheme(.dark)
    }
}
